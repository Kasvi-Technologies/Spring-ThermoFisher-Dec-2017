
public class Test {

	//main is the startinhg method which is used execute java applications
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//BL..
		System.out.println("FIrst Java application..");
	}

}
