package com.samples.beans;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Employee implements InitializingBean , DisposableBean{
	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("after properties set method from Initializing bean");
	}

	public Employee(){
		
	}
	
	public Employee(int id, String name, double salary, Address address) {
		System.out.println("paratermized constru...");
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.address = address;
	}
	public void preProcess(){
		System.out.println("This BL will be executed after completion of"
				+ "setter methods..");
	}
	
	public void destroy(){
		System.out.println("executed by spring container ehenver this bean"
				+ "is removed ");
	}
	public Employee(int id, String name) {
		//System.out.println("paratermized constru...");
		this.id = id;
		this.name = name;
		
	}
	
	private int id;
	

	private String name;
	private double salary;
	private Address address;
	//private Department dept;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		System.out.println("in set address method..");
		this.address = address;
	}

	
	
}
