package com.samples.beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//<bean id="stock" class="" />

@Component("stock" )
@Scope(value="prototype")

public class Stock {

	private int stockId;
	private String stockName;
	private double stockPrice;
	public int getStockId() {
		return stockId;
	}
	@Value("100")
	public void setStockId(int stockId) {
		this.stockId = stockId;
	}
	public String getStockName() {
		return stockName;
	}
	@Value("ThermoFishers")
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public double getStockPrice() {
		return stockPrice;
	}
	@Value("100")
	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}
	
	@PostConstruct
	public void preProcess(){
		System.out.println("Post Construct annotation..");
	}
	
	@PreDestroy
	public void preDestroy(){
		
	}
	
	
}
