package com.samples.service;

import java.util.ArrayList;
import java.util.List;

import com.samples.beans.Product;
import com.samples.dao.ProductDAO;

public class ProductService {

	private ProductDAO productDAO ;
	
	public ProductDAO getProductDAO() {
		return productDAO;
	}
	public void setProductDAO(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}
	//Service classes will contain only business logic and then it will
	//call the dao methods..
	public void insertProduct(Product product) {
		System.out.println("product service insert product");
		productDAO.insertProduct(product);
	}
	public void deleteProduct(int productId) {
		System.out.println("product service delete product");
		productDAO.deleteProduct(productId);
	}
	public void updatProduct(Product product) {
		System.out.println("product service update product");
		productDAO.updatProduct(product);
	}
	public List<Product> fetchProducts() {
		System.out.println("product service fetch product");		
		List<Product> productList = productDAO.fetchProducts();
		return productList;
	}
	
	public void sampleExceptionMethod () throws Exception{
		throw new Exception("product not found");
	}
	
}
