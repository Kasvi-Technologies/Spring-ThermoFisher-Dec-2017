package com.samples.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.samples.beans.Stock;
import com.samples.dao.StockDAO;

@Service("stockService")
public class StockService {
	@Autowired
	private StockDAO stockDAO;	
	public StockDAO getStockDAO() {
		return stockDAO;
	}
	public void setStockDAO(StockDAO stockDAO) {
		this.stockDAO = stockDAO;
	}
	public void insertStock(Stock s){
		System.out.println("Stock Service: inserttStock");
		stockDAO.insertStock(s);
	}	
	public List<Stock> fetchStocks(){
		System.out.println("StockService: fetchStocks");
		List<Stock> stockList = stockDAO.fetchStocks();
		return stockList;
		
	}
	
}
