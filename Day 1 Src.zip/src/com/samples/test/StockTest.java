package com.samples.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.samples.beans.Product;
import com.samples.beans.Stock;
import com.samples.service.ProductService;
import com.samples.service.StockService;

public class StockTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory =  
				new ClassPathXmlApplicationContext("annotationbeans.xml");
		
		Stock stock = (Stock) factory.getBean("stock");
		
		StockService stockService = 
				(StockService) factory.getBean("stockService");
		
		stockService.insertStock(stock);
		List<Stock> stockList = stockService.fetchStocks();
		System.out.println(stockList.size());
	}

}
