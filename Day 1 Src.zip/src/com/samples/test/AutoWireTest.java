package com.samples.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.samples.beans.Employee;
import com.samples.beans.Product;

public class AutoWireTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory =  
				new ClassPathXmlApplicationContext("autowireexbeans.xml");
		
		
		Employee emp = (Employee) factory.getBean("employee");
		System.out.println(emp.getAddress().getId());
		
		
	}

}
