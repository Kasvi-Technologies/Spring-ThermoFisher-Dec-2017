package com.samples.test;

import com.samples.beans.Product;

public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Product p = new Product();
		p.setId(100);
		p.setName("Produt1");
		p.setPrice(1000);
		p.setDescription("Product1 description..");
		
		System.out.println(p.getId() + " " + p.getName() + 
				" " + p.getPrice() + " " + p.getDescription());
	}

}
