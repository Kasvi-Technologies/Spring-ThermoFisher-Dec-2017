package com.samples.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

import com.samples.beans.Employee;
import com.samples.beans.Product;

public class SpringBasedProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//List list = new ArrayList();
		//Load beans.xml file using Beanfactory
//		BeanFactory factory = new XmlBeanFactory(
//				new FileSystemResource("src/beans.xml"));
//		//C:\Users\trainee10\workspace\Spring\src\beans.xml
		
		ApplicationContext factory =  
				new ClassPathXmlApplicationContext("beans.xml");
		
		Product product = (Product) factory.getBean("product");
		
		System.out.println(product.getId() + " " + product.getName() + 
				" " + product.getPrice() + " " + product.getDescription());
		
		Employee emp = (Employee) factory.getBean("employee");
		
		Employee emp1 = (Employee) factory.getBean("employeeUsingPraramCon");
		
		System.out.println(emp.getAddress());
		System.out.println(emp1.getAddress());
		
	}

}
