package com.samples.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.samples.beans.Product;
import com.samples.service.ProductService;

public class ProductServicetest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory =  
				new ClassPathXmlApplicationContext("beans.xml");
		
		Product product = (Product) factory.getBean("product");
		
		ProductService productService = 
				(ProductService) factory.getBean("productServiceBeforeProxy");
		
		productService.insertProduct(product);
		productService.updatProduct(product);
		productService.deleteProduct(100);
		List<Product> productList = productService.fetchProducts();
		
		System.out.println("Size:"+ productList.size());
		
	}

}
