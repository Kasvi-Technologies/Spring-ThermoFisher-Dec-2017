package com.samples.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.samples.beans.Stock;

@Repository("stockDAO")
public class StockDAO {

	public void insertStock(Stock s){
		System.out.println("Stock DAO: inserttStock");
	}
	
	public List<Stock> fetchStocks(){
		System.out.println("StockDAO: fetchStocks");
		List<Stock> stockList = new ArrayList<Stock> ();
		return stockList;
		
	}
	
}
