package com.samples.dao;

import java.util.ArrayList;
import java.util.List;

import com.samples.beans.Product;

public class ProductDAO {
	//DAO will contain only database logic
	//Data Access Object
	public void insertProduct(Product product) {
		System.out.println("product DAO insert product");
	}
	public void deleteProduct(int productId) {
		System.out.println("product DAO delete product");
	}
	public void updatProduct(Product product) {
		System.out.println("product DAO update product");
	}
	public List<Product> fetchProducts() {
		List<Product> productList = new ArrayList<Product>();
		System.out.println("product DAO fetch product");
		return productList;
	}


}
