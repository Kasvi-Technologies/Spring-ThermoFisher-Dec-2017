package com.samples.advice;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;



public class BeforeLoggingAspect implements MethodBeforeAdvice{

	//This  method will automatically executed before calling your
	//business logic methods... 
	
	//Method argument contains your business logic related method info
	
	@Override
	public void before(Method method, Object[] arg1, Object target)
			throws Throwable {
		// TODO Auto-generated method stub
		System.out.println("BeforeLoggingAspect called before " +
								method.getName());
		
		System.out.println("arguments:" + arg1);
		
		System.out.println("Target object: " + target);
		
		
	}

	
}
