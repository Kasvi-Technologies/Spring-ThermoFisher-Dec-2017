package com.samples.advice;

import org.springframework.aop.ThrowsAdvice;

public class ProductExceptionAspect implements ThrowsAdvice{
	
	public void afterThrowing(Exception e) throws Exception{
		System.out.println(e.getMessage() + " from ProductExceptionAspect:");
	}

}
