package com.samples.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//
public class Login extends HttpServlet{

	//method="get"
	public void doGet(HttpServletRequest request , 
							HttpServletResponse response)
						throws ServletException, IOException{
		System.out.println("in do get..");
	}
	
	//method="post"
	public void doPost(HttpServletRequest request , 
							HttpServletResponse response)
							throws ServletException, IOException{
		System.out.println("in do post..");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		System.out.println(username  + " " + password);
		String nextPage = "login.html";
		if("Admin".equals(username) && "Admin".equals(password)){
			nextPage="loginsuccess.html";
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
		
		
	}
}
